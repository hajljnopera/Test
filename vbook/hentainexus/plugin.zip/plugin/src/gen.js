function execute(url, page) {
    if (!page) page = '1';
    const doc = Http.get(url + 'page/' + page).html();

    var next = doc.select("nav.pagination-top > a.pagination-next").text();

    const el = doc.select(".column .card-header-title");

    const data = [];

    const link = 'https://hentainexus.com';

    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        data.push({
            name: 'Name goes here',
            link: link,
            cover: e.select(".column:nth-child(2) img").attr("src"),
            description: '',
            host: link
        })
    }

    return Response.success(data, next)
}


