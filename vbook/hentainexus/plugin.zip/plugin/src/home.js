function execute() {
    return Response.success([
        { title: "Home", input: "https://hentainexus.com/", script: "gen.js" },
    ]);
}